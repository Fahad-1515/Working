import React, { useState } from "react";

export default function CalculatorApp() {
  const [result, setResult] = useState(0);
  const [input, setInput] = useState("");

  const handleChange = (e) => {
    setInput(e.target.value);
  };

  const getNumber = () => {
    const num = parseFloat(input);
    return isNaN(num) ? 0 : num;
  };

  const add = () => setResult(result + getNumber());
  const subtract = () => setResult(result - getNumber());
  const multiply = () => setResult(result * getNumber());
  const divide = () => {
    const num = getNumber();
    if (num !== 0) setResult(result / num);
    else alert("Cannot divide by zero");
  };

  const resetInput = () => setInput("");
  const resetResult = () => setResult(0);

  return (
    <div style={styles.container}>
      <h1>Simplest Working Calculator</h1>
      <h2>{result}</h2>
      <input
        type="text"
        value={input}
        onChange={handleChange}
        style={styles.input}
      />
      <div style={styles.buttonContainer}>
        <button onClick={add}>add</button>
        <button onClick={subtract}>subtract</button>
        <button onClick={multiply}>multiply</button>
        <button onClick={divide}>divide</button>
        <button onClick={resetInput} style={styles.resetButton}>
          reset input
        </button>
        <button onClick={resetResult} style={styles.resetButton}>
          reset result
        </button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    fontFamily: "Arial",
    padding: "30px",
    maxWidth: "400px",
    margin: "auto",
  },
  input: {
    fontSize: "20px",
    padding: "10px",
    width: "100%",
    marginBottom: "10px",
  },
  buttonContainer: {
    display: "flex",
    flexWrap: "wrap",
    gap: "10px",
  },
  resetButton: {
    backgroundColor: "#f75d3f",
    color: "white",
    border: "none",
    padding: "10px 15px",
    cursor: "pointer",
  },
};